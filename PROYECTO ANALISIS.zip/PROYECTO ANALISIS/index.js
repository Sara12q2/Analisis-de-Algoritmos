var c = []; //arreglo de inicio
var f = []; //arreglo de fin
var s = []; //arreglo de solucion


function createElements(){
    var datosEntrada=new Array();
    var datosSalida=new Array();s
    var inputEntrada=document.getElementsByClassName('valoresIniciales');
    var inputSalida=document.getElementsByClassName('valoresFinales');
    
    namesValues=[].map.call(inputEntrada,function(dataInput){
        datosEntrada.push(dataInput.value);

    });
   
    namesValues=[].map.call(inputSalida,function(dataInput){
        datosSalida.push(dataInput.value);

    });
    console.log(datosEntrada);
    console.log(datosSalida);
    
   //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    datosEntrada.forEach(element => {//Para cada valor del array
        element.split(",").forEach(elm => {//Lo divido en 2 por la coma y para cada uno de los resultados
            c.push(parseInt(elm));//LO meto en el array fin haciéndole un parse a float para evitar comillas
        });
    });
    console.log(c); 
    n=c.length; //logitud de arreglo de inicio
   // console.log(n);
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////77
    datosSalida.forEach(element => {//Para cada valor del array
        element.split(",").forEach(elm => {//Lo divido en 2 por la coma y para cada uno de los resultados
            f.push(parseInt(elm));//LO meto en el array fin haciéndole un parse a float para evitar comillas
        });
    });
    console.log(f); 
    
 
}

function num(n){
     n=c.length;
     console.log("el valor de n es: ",n);

    return n;
}

function mostrar(n){
    var  n=c.length;

    console.log("Actividades");
    for(var i=0;i<n;i++){
     //arreglo c

       console.log(i+1);
    }

    console.log("inicio");
    for(var i=0;i<n;i++){
     //arreglo c

       console.log(c[i]);
    }
       console.log("fin ");
    for(var i=0;i<n;i++){
     //arreglo f
     
     console.log(f[i]);
    }       
}

function ordenar() {
    var  n=c.length;
    let aux1,aux2,aux3,band=1
    for(var i=n-1;i>0 && band==1; i--)
    {
        band=0;
        for(var j=0; j<i ; j++){
            if(f[j]>f[j+1]){
                aux1 = f[j];
                f[j]=f[j+1];
                f[j+1]=aux1;
                aux2 = c[j];
                c[j]=c[j+1];
                c[j+1]=aux2;
                band=1;
            }
        }
    } 
    mostrar(n);
}

function algoritmo(){
    
    ordenar();
    var  n=c.length;
    let z,k=1;
    s[0]=0;
    z=0;
    for(var i=1;i<n;i++){
        if(c[i]>=f[z]){
            s[k]=i;
            z=i;
            k++;
        }
    }
    var ns=s.length;
    console.log("NN es: ",ns);
    console.log(s);
}

